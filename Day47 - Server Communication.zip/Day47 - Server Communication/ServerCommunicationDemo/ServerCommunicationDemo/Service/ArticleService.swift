//
//  ArticleService.swift
//  ServerCommunicationDemo
//
//  Created by Kokpheng on 12/15/17.
//  Copyright © 2017 Kokpheng. All rights reserved.
//

import Foundation


class ArticleService {
    
    func getData(pageNumber: Int) {
        
    }
    
    func getArticle(by id: String) {
       
    }
    
    func addArticle(paramaters: [String: Any]) {
        
    }
    
    func updateArticle(with id: String, paramaters: [String: Any]) {
       
    }
    
    func deleteArticle(with id: String, completion: @escaping (Error?) -> ()) {
        
    }
    
    func uploadFile(file : Data, completion: @escaping (String?, Error?) -> ()) {
        
    }
}
