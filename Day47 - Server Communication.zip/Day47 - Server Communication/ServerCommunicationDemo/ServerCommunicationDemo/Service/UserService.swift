//
//  UserService.swift
//  ServerCommunicationDemo
//
//  Created by Kokpheng on 12/15/17.
//  Copyright © 2017 Kokpheng. All rights reserved.
//

import Foundation

class UserService {
    
//    func singup(paramaters: [String: String], files: [String:Data], completion: @escaping (DataResponse<Any>?, Error?)->()) {
//        
//    }
//    
//    func signin(paramaters: [String: Any], completion: @escaping (DataResponse<Any>?, Error?)->()) {
//        
//    }
}
